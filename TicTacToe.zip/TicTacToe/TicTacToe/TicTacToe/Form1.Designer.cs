﻿namespace TicTacToe
{
    partial class form_ticTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_ticTacToe));
            this.pictureBox_Grid = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_wibitScore = new System.Windows.Forms.Label();
            this.label_buzzScore = new System.Windows.Forms.Label();
            this.pictureBox_frogAwake = new System.Windows.Forms.PictureBox();
            this.pictureBox_frogAsleep = new System.Windows.Forms.PictureBox();
            this.pictureBox_flyAwake = new System.Windows.Forms.PictureBox();
            this.pictureBox_flyAsleep = new System.Windows.Forms.PictureBox();
            this.pictureBox1_o = new System.Windows.Forms.PictureBox();
            this.pictureBox2_o = new System.Windows.Forms.PictureBox();
            this.pictureBox3_o = new System.Windows.Forms.PictureBox();
            this.pictureBox4_o = new System.Windows.Forms.PictureBox();
            this.pictureBox5_o = new System.Windows.Forms.PictureBox();
            this.pictureBox6_o = new System.Windows.Forms.PictureBox();
            this.pictureBox7_o = new System.Windows.Forms.PictureBox();
            this.pictureBox8_o = new System.Windows.Forms.PictureBox();
            this.pictureBox9_o = new System.Windows.Forms.PictureBox();
            this.pictureBox1_x = new System.Windows.Forms.PictureBox();
            this.pictureBox2_x = new System.Windows.Forms.PictureBox();
            this.pictureBox3_x = new System.Windows.Forms.PictureBox();
            this.pictureBox4_x = new System.Windows.Forms.PictureBox();
            this.pictureBox5_x = new System.Windows.Forms.PictureBox();
            this.pictureBox6_x = new System.Windows.Forms.PictureBox();
            this.pictureBox7_x = new System.Windows.Forms.PictureBox();
            this.pictureBox8_x = new System.Windows.Forms.PictureBox();
            this.pictureBox9_x = new System.Windows.Forms.PictureBox();
            this.pictureBox1_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox2_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox3_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox4_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox5_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox6_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox7_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox8_blank = new System.Windows.Forms.PictureBox();
            this.pictureBox9_blank = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_frogAwake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_frogAsleep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_flyAwake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_flyAsleep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_blank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_blank)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_Grid
            // 
            this.pictureBox_Grid.Image = global::TicTacToe.Properties.Resources.Grid;
            this.pictureBox_Grid.Location = new System.Drawing.Point(145, 35);
            this.pictureBox_Grid.Name = "pictureBox_Grid";
            this.pictureBox_Grid.Size = new System.Drawing.Size(584, 554);
            this.pictureBox_Grid.TabIndex = 0;
            this.pictureBox_Grid.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TicTacToe.Properties.Resources.ButtonLogo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(254, 53);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(660, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "WiBit The Frog";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(678, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Buzz The Fly";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(657, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Vs.";
            // 
            // label_wibitScore
            // 
            this.label_wibitScore.AutoSize = true;
            this.label_wibitScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_wibitScore.Location = new System.Drawing.Point(826, 13);
            this.label_wibitScore.Name = "label_wibitScore";
            this.label_wibitScore.Size = new System.Drawing.Size(21, 24);
            this.label_wibitScore.TabIndex = 5;
            this.label_wibitScore.Text = "0";
            // 
            // label_buzzScore
            // 
            this.label_buzzScore.AutoSize = true;
            this.label_buzzScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_buzzScore.Location = new System.Drawing.Point(826, 41);
            this.label_buzzScore.Name = "label_buzzScore";
            this.label_buzzScore.Size = new System.Drawing.Size(21, 24);
            this.label_buzzScore.TabIndex = 6;
            this.label_buzzScore.Text = "0";
            // 
            // pictureBox_frogAwake
            // 
            this.pictureBox_frogAwake.Image = global::TicTacToe.Properties.Resources.Frog_Awake;
            this.pictureBox_frogAwake.Location = new System.Drawing.Point(11, 405);
            this.pictureBox_frogAwake.Name = "pictureBox_frogAwake";
            this.pictureBox_frogAwake.Size = new System.Drawing.Size(189, 164);
            this.pictureBox_frogAwake.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_frogAwake.TabIndex = 7;
            this.pictureBox_frogAwake.TabStop = false;
            // 
            // pictureBox_frogAsleep
            // 
            this.pictureBox_frogAsleep.Image = global::TicTacToe.Properties.Resources.Frog_Asleep;
            this.pictureBox_frogAsleep.Location = new System.Drawing.Point(11, 418);
            this.pictureBox_frogAsleep.Name = "pictureBox_frogAsleep";
            this.pictureBox_frogAsleep.Size = new System.Drawing.Size(189, 151);
            this.pictureBox_frogAsleep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_frogAsleep.TabIndex = 8;
            this.pictureBox_frogAsleep.TabStop = false;
            // 
            // pictureBox_flyAwake
            // 
            this.pictureBox_flyAwake.Image = global::TicTacToe.Properties.Resources.Fly_Awake;
            this.pictureBox_flyAwake.Location = new System.Drawing.Point(669, 386);
            this.pictureBox_flyAwake.Name = "pictureBox_flyAwake";
            this.pictureBox_flyAwake.Size = new System.Drawing.Size(192, 182);
            this.pictureBox_flyAwake.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_flyAwake.TabIndex = 9;
            this.pictureBox_flyAwake.TabStop = false;
            // 
            // pictureBox_flyAsleep
            // 
            this.pictureBox_flyAsleep.Image = global::TicTacToe.Properties.Resources.Fly_Asleep;
            this.pictureBox_flyAsleep.Location = new System.Drawing.Point(694, 472);
            this.pictureBox_flyAsleep.Name = "pictureBox_flyAsleep";
            this.pictureBox_flyAsleep.Size = new System.Drawing.Size(151, 96);
            this.pictureBox_flyAsleep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_flyAsleep.TabIndex = 10;
            this.pictureBox_flyAsleep.TabStop = false;
            // 
            // pictureBox1_o
            // 
            this.pictureBox1_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox1_o.Location = new System.Drawing.Point(207, 72);
            this.pictureBox1_o.Name = "pictureBox1_o";
            this.pictureBox1_o.Size = new System.Drawing.Size(118, 119);
            this.pictureBox1_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_o.TabIndex = 11;
            this.pictureBox1_o.TabStop = false;
            // 
            // pictureBox2_o
            // 
            this.pictureBox2_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox2_o.Location = new System.Drawing.Point(371, 95);
            this.pictureBox2_o.Name = "pictureBox2_o";
            this.pictureBox2_o.Size = new System.Drawing.Size(107, 109);
            this.pictureBox2_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2_o.TabIndex = 12;
            this.pictureBox2_o.TabStop = false;
            // 
            // pictureBox3_o
            // 
            this.pictureBox3_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox3_o.Location = new System.Drawing.Point(515, 76);
            this.pictureBox3_o.Name = "pictureBox3_o";
            this.pictureBox3_o.Size = new System.Drawing.Size(118, 119);
            this.pictureBox3_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3_o.TabIndex = 13;
            this.pictureBox3_o.TabStop = false;
            // 
            // pictureBox4_o
            // 
            this.pictureBox4_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox4_o.Location = new System.Drawing.Point(198, 235);
            this.pictureBox4_o.Name = "pictureBox4_o";
            this.pictureBox4_o.Size = new System.Drawing.Size(118, 119);
            this.pictureBox4_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4_o.TabIndex = 14;
            this.pictureBox4_o.TabStop = false;
            // 
            // pictureBox5_o
            // 
            this.pictureBox5_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox5_o.Location = new System.Drawing.Point(370, 239);
            this.pictureBox5_o.Name = "pictureBox5_o";
            this.pictureBox5_o.Size = new System.Drawing.Size(107, 109);
            this.pictureBox5_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5_o.TabIndex = 15;
            this.pictureBox5_o.TabStop = false;
            // 
            // pictureBox6_o
            // 
            this.pictureBox6_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox6_o.Location = new System.Drawing.Point(509, 229);
            this.pictureBox6_o.Name = "pictureBox6_o";
            this.pictureBox6_o.Size = new System.Drawing.Size(118, 119);
            this.pictureBox6_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6_o.TabIndex = 16;
            this.pictureBox6_o.TabStop = false;
            // 
            // pictureBox7_o
            // 
            this.pictureBox7_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox7_o.Location = new System.Drawing.Point(216, 405);
            this.pictureBox7_o.Name = "pictureBox7_o";
            this.pictureBox7_o.Size = new System.Drawing.Size(118, 119);
            this.pictureBox7_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7_o.TabIndex = 17;
            this.pictureBox7_o.TabStop = false;
            // 
            // pictureBox8_o
            // 
            this.pictureBox8_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox8_o.Location = new System.Drawing.Point(362, 399);
            this.pictureBox8_o.Name = "pictureBox8_o";
            this.pictureBox8_o.Size = new System.Drawing.Size(122, 119);
            this.pictureBox8_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8_o.TabIndex = 18;
            this.pictureBox8_o.TabStop = false;
            // 
            // pictureBox9_o
            // 
            this.pictureBox9_o.Image = global::TicTacToe.Properties.Resources.o;
            this.pictureBox9_o.Location = new System.Drawing.Point(512, 393);
            this.pictureBox9_o.Name = "pictureBox9_o";
            this.pictureBox9_o.Size = new System.Drawing.Size(118, 119);
            this.pictureBox9_o.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9_o.TabIndex = 19;
            this.pictureBox9_o.TabStop = false;
            // 
            // pictureBox1_x
            // 
            this.pictureBox1_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox1_x.Location = new System.Drawing.Point(207, 71);
            this.pictureBox1_x.Name = "pictureBox1_x";
            this.pictureBox1_x.Size = new System.Drawing.Size(118, 119);
            this.pictureBox1_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_x.TabIndex = 20;
            this.pictureBox1_x.TabStop = false;
            // 
            // pictureBox2_x
            // 
            this.pictureBox2_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox2_x.Location = new System.Drawing.Point(371, 95);
            this.pictureBox2_x.Name = "pictureBox2_x";
            this.pictureBox2_x.Size = new System.Drawing.Size(107, 109);
            this.pictureBox2_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2_x.TabIndex = 21;
            this.pictureBox2_x.TabStop = false;
            // 
            // pictureBox3_x
            // 
            this.pictureBox3_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox3_x.Location = new System.Drawing.Point(515, 76);
            this.pictureBox3_x.Name = "pictureBox3_x";
            this.pictureBox3_x.Size = new System.Drawing.Size(118, 119);
            this.pictureBox3_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3_x.TabIndex = 22;
            this.pictureBox3_x.TabStop = false;
            // 
            // pictureBox4_x
            // 
            this.pictureBox4_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox4_x.Location = new System.Drawing.Point(198, 235);
            this.pictureBox4_x.Name = "pictureBox4_x";
            this.pictureBox4_x.Size = new System.Drawing.Size(118, 119);
            this.pictureBox4_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4_x.TabIndex = 23;
            this.pictureBox4_x.TabStop = false;
            // 
            // pictureBox5_x
            // 
            this.pictureBox5_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox5_x.Location = new System.Drawing.Point(371, 239);
            this.pictureBox5_x.Name = "pictureBox5_x";
            this.pictureBox5_x.Size = new System.Drawing.Size(107, 109);
            this.pictureBox5_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5_x.TabIndex = 24;
            this.pictureBox5_x.TabStop = false;
            // 
            // pictureBox6_x
            // 
            this.pictureBox6_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox6_x.Location = new System.Drawing.Point(509, 229);
            this.pictureBox6_x.Name = "pictureBox6_x";
            this.pictureBox6_x.Size = new System.Drawing.Size(118, 119);
            this.pictureBox6_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6_x.TabIndex = 25;
            this.pictureBox6_x.TabStop = false;
            // 
            // pictureBox7_x
            // 
            this.pictureBox7_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox7_x.Location = new System.Drawing.Point(216, 405);
            this.pictureBox7_x.Name = "pictureBox7_x";
            this.pictureBox7_x.Size = new System.Drawing.Size(118, 119);
            this.pictureBox7_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7_x.TabIndex = 26;
            this.pictureBox7_x.TabStop = false;
            // 
            // pictureBox8_x
            // 
            this.pictureBox8_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox8_x.Location = new System.Drawing.Point(362, 399);
            this.pictureBox8_x.Name = "pictureBox8_x";
            this.pictureBox8_x.Size = new System.Drawing.Size(122, 119);
            this.pictureBox8_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8_x.TabIndex = 27;
            this.pictureBox8_x.TabStop = false;
            // 
            // pictureBox9_x
            // 
            this.pictureBox9_x.Image = global::TicTacToe.Properties.Resources.x;
            this.pictureBox9_x.Location = new System.Drawing.Point(512, 393);
            this.pictureBox9_x.Name = "pictureBox9_x";
            this.pictureBox9_x.Size = new System.Drawing.Size(118, 119);
            this.pictureBox9_x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9_x.TabIndex = 28;
            this.pictureBox9_x.TabStop = false;
            // 
            // pictureBox1_blank
            // 
            this.pictureBox1_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_blank.Image")));
            this.pictureBox1_blank.Location = new System.Drawing.Point(207, 72);
            this.pictureBox1_blank.Name = "pictureBox1_blank";
            this.pictureBox1_blank.Size = new System.Drawing.Size(118, 119);
            this.pictureBox1_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_blank.TabIndex = 29;
            this.pictureBox1_blank.TabStop = false;
            this.pictureBox1_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox2_blank
            // 
            this.pictureBox2_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2_blank.Image")));
            this.pictureBox2_blank.Location = new System.Drawing.Point(370, 95);
            this.pictureBox2_blank.Name = "pictureBox2_blank";
            this.pictureBox2_blank.Size = new System.Drawing.Size(107, 109);
            this.pictureBox2_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2_blank.TabIndex = 30;
            this.pictureBox2_blank.TabStop = false;
            this.pictureBox2_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox3_blank
            // 
            this.pictureBox3_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_blank.Image")));
            this.pictureBox3_blank.Location = new System.Drawing.Point(515, 76);
            this.pictureBox3_blank.Name = "pictureBox3_blank";
            this.pictureBox3_blank.Size = new System.Drawing.Size(118, 119);
            this.pictureBox3_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3_blank.TabIndex = 31;
            this.pictureBox3_blank.TabStop = false;
            this.pictureBox3_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox4_blank
            // 
            this.pictureBox4_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_blank.Image")));
            this.pictureBox4_blank.Location = new System.Drawing.Point(198, 235);
            this.pictureBox4_blank.Name = "pictureBox4_blank";
            this.pictureBox4_blank.Size = new System.Drawing.Size(118, 119);
            this.pictureBox4_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4_blank.TabIndex = 32;
            this.pictureBox4_blank.TabStop = false;
            this.pictureBox4_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox5_blank
            // 
            this.pictureBox5_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_blank.Image")));
            this.pictureBox5_blank.Location = new System.Drawing.Point(371, 239);
            this.pictureBox5_blank.Name = "pictureBox5_blank";
            this.pictureBox5_blank.Size = new System.Drawing.Size(107, 109);
            this.pictureBox5_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5_blank.TabIndex = 33;
            this.pictureBox5_blank.TabStop = false;
            this.pictureBox5_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox6_blank
            // 
            this.pictureBox6_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_blank.Image")));
            this.pictureBox6_blank.Location = new System.Drawing.Point(509, 229);
            this.pictureBox6_blank.Name = "pictureBox6_blank";
            this.pictureBox6_blank.Size = new System.Drawing.Size(118, 119);
            this.pictureBox6_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6_blank.TabIndex = 34;
            this.pictureBox6_blank.TabStop = false;
            this.pictureBox6_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox7_blank
            // 
            this.pictureBox7_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_blank.Image")));
            this.pictureBox7_blank.Location = new System.Drawing.Point(216, 405);
            this.pictureBox7_blank.Name = "pictureBox7_blank";
            this.pictureBox7_blank.Size = new System.Drawing.Size(118, 119);
            this.pictureBox7_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7_blank.TabIndex = 35;
            this.pictureBox7_blank.TabStop = false;
            this.pictureBox7_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox8_blank
            // 
            this.pictureBox8_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8_blank.Image")));
            this.pictureBox8_blank.Location = new System.Drawing.Point(362, 399);
            this.pictureBox8_blank.Name = "pictureBox8_blank";
            this.pictureBox8_blank.Size = new System.Drawing.Size(122, 119);
            this.pictureBox8_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8_blank.TabIndex = 36;
            this.pictureBox8_blank.TabStop = false;
            this.pictureBox8_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // pictureBox9_blank
            // 
            this.pictureBox9_blank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9_blank.Image")));
            this.pictureBox9_blank.Location = new System.Drawing.Point(512, 393);
            this.pictureBox9_blank.Name = "pictureBox9_blank";
            this.pictureBox9_blank.Size = new System.Drawing.Size(118, 119);
            this.pictureBox9_blank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9_blank.TabIndex = 37;
            this.pictureBox9_blank.TabStop = false;
            this.pictureBox9_blank.Click += new System.EventHandler(this.pictureBox_blank_Click);
            // 
            // form_ticTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 586);
            this.Controls.Add(this.pictureBox9_blank);
            this.Controls.Add(this.pictureBox8_blank);
            this.Controls.Add(this.pictureBox7_blank);
            this.Controls.Add(this.pictureBox6_blank);
            this.Controls.Add(this.pictureBox5_blank);
            this.Controls.Add(this.pictureBox4_blank);
            this.Controls.Add(this.pictureBox3_blank);
            this.Controls.Add(this.pictureBox2_blank);
            this.Controls.Add(this.pictureBox1_blank);
            this.Controls.Add(this.pictureBox9_x);
            this.Controls.Add(this.pictureBox8_x);
            this.Controls.Add(this.pictureBox7_x);
            this.Controls.Add(this.pictureBox6_x);
            this.Controls.Add(this.pictureBox5_x);
            this.Controls.Add(this.pictureBox4_x);
            this.Controls.Add(this.pictureBox3_x);
            this.Controls.Add(this.pictureBox2_x);
            this.Controls.Add(this.pictureBox1_x);
            this.Controls.Add(this.pictureBox9_o);
            this.Controls.Add(this.pictureBox8_o);
            this.Controls.Add(this.pictureBox7_o);
            this.Controls.Add(this.pictureBox6_o);
            this.Controls.Add(this.pictureBox5_o);
            this.Controls.Add(this.pictureBox4_o);
            this.Controls.Add(this.pictureBox3_o);
            this.Controls.Add(this.pictureBox2_o);
            this.Controls.Add(this.pictureBox1_o);
            this.Controls.Add(this.pictureBox_flyAsleep);
            this.Controls.Add(this.pictureBox_flyAwake);
            this.Controls.Add(this.pictureBox_frogAsleep);
            this.Controls.Add(this.pictureBox_frogAwake);
            this.Controls.Add(this.label_buzzScore);
            this.Controls.Add(this.label_wibitScore);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox_Grid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "form_ticTacToe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WiBit.Net Presents :: TicTacToe";
            this.Load += new System.EventHandler(this.form_ticTacToe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_frogAwake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_frogAsleep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_flyAwake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_flyAsleep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_blank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_blank)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.PictureBox pictureBox_Grid;
        public System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_wibitScore;
        private System.Windows.Forms.Label label_buzzScore;
        public System.Windows.Forms.PictureBox pictureBox_frogAwake;
        public System.Windows.Forms.PictureBox pictureBox_frogAsleep;
        public System.Windows.Forms.PictureBox pictureBox_flyAwake;
        public System.Windows.Forms.PictureBox pictureBox_flyAsleep;
        public System.Windows.Forms.PictureBox pictureBox1_o;
        public System.Windows.Forms.PictureBox pictureBox2_o;
        public System.Windows.Forms.PictureBox pictureBox3_o;
        public System.Windows.Forms.PictureBox pictureBox4_o;
        public System.Windows.Forms.PictureBox pictureBox5_o;
        public System.Windows.Forms.PictureBox pictureBox6_o;
        public System.Windows.Forms.PictureBox pictureBox7_o;
        public System.Windows.Forms.PictureBox pictureBox8_o;
        public System.Windows.Forms.PictureBox pictureBox9_o;
        public System.Windows.Forms.PictureBox pictureBox1_x;
        public System.Windows.Forms.PictureBox pictureBox2_x;
        public System.Windows.Forms.PictureBox pictureBox3_x;
        public System.Windows.Forms.PictureBox pictureBox4_x;
        public System.Windows.Forms.PictureBox pictureBox5_x;
        public System.Windows.Forms.PictureBox pictureBox6_x;
        public System.Windows.Forms.PictureBox pictureBox7_x;
        public System.Windows.Forms.PictureBox pictureBox8_x;
        public System.Windows.Forms.PictureBox pictureBox9_x;
        public System.Windows.Forms.PictureBox pictureBox1_blank;
        public System.Windows.Forms.PictureBox pictureBox2_blank;
        public System.Windows.Forms.PictureBox pictureBox3_blank;
        public System.Windows.Forms.PictureBox pictureBox4_blank;
        public System.Windows.Forms.PictureBox pictureBox5_blank;
        public System.Windows.Forms.PictureBox pictureBox6_blank;
        public System.Windows.Forms.PictureBox pictureBox7_blank;
        public System.Windows.Forms.PictureBox pictureBox8_blank;
        public System.Windows.Forms.PictureBox pictureBox9_blank;
    }
}

